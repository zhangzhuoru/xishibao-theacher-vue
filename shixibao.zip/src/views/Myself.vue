<template>
  <div class="myself">
    <img class="user-poster" src="https://img.yzcdn.cn/public_files/2017/10/23/8690bb321356070e0b8c4404d087f8fd.png">
    <van-row class="user-links">
      <van-col span="6" @click='gotomoney'>
        <van-icon name="pending-payment" />
        余额
      </van-col>
      <van-col span="6">
        <van-icon name="records" />
        全部通话
      </van-col>
      <van-col span="6" @click='gototelephonecharge'>
        <van-icon name="tosend" />
        充值
      </van-col>
      <van-col span="6" @click='gotorechargerecord'>
        <van-icon name="logistics" />
        充值记录
      </van-col>
    </van-row>

    <van-cell-group class="user-group">
      <van-cell icon="points" title="个人信息管理" is-link @click='gotoeditordata'/>
      <van-cell icon="gift-o" title="修改密码" is-link @click='gotochangepassword'/>
      <van-cell icon="points" title="定位方式" is-link />
      <van-cell icon="gold-coin-o" title="地图下载" is-link />
      <van-cell  title="单元格" icon="gold-coin-o" is-link />
    </van-cell-group>

    <van-cell-group>
      <van-cell icon="gift-o" title="黑名单" is-link />
      <van-cell icon="gift-o" title="关于我们" is-link />
    </van-cell-group>
    <van-cell-group class="user-group">
      <button class="but">退出登录</button>
    </van-cell-group>
  </div>
</template>

<script>
// @ is an alias to /src


export default {
  name: 'myself',
  data() {
			return {
        visible:true
      }
  },
  created () {
      console.log(this.$router.currentRoute.path)
  },
  methods: {
    gototelephonecharge(){
      this.$router.push({path:'/telephonecharge'})
    },
    gotorechargerecord(){
      this.$router.push({path:'/rechargerecord'})
    },
    gotomoney(){
      this.$router.push({path:'/money'})
    },
    gotochangepassword(){
      this.$router.push({path:'/changepassword'})
    },
    gotoeditordata(){
      this.$router.push({path:'/editordata'})
    }
  },

}
</script>

<style lang="scss" scoped>
.myself{
  padding-top: 40px;
  padding-bottom: 60px;
  overflow-x: hidden;
  min-height: calc(100vh-100px);
  background-color: #fff;
}
.user-poster {
    width: 100%;
    height: 53vw;
    display: block;
    margin-bottom: 15px;
  }
  .user-group {
    margin-bottom: 15px;
  }
  .user-links {
    padding: 15px 0;
    font-size: 12px;
    text-align: center;
    background-color: #fff;
  }
    .van-icon {
      display: block;
      font-size: 24px;
    }
  

.but{
  height: 6vh;
  width: 100%;
  background-color: #fff;
  color: red;
  border: none;
  font-size: 14px;
}
</style>