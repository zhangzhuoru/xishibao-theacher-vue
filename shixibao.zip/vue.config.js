module.exports = {
    lintOnSave:false,
    baseUrl:'.'
}